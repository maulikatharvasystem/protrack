//
//  JVCommonBannerView.h
//  Javee
//
//

#import <UIKit/UIKit.h>
#import "JVBannerControllerDelegate.h"

@interface JVCommonBannerView : UIView {
  BOOL isNeedCloseButton;
}

@property (nonatomic, assign) id<JVBannerControllerDelegate> delegate;

- (void)updateBannerAfterChangeOrientation;

@end
