//
//  JVRequestData.h
//  Javee
//
//

#import <Foundation/Foundation.h>
#import "JVConnection.h"

@protocol JVRequestDataDelegate <NSObject>
 @optional
  - (void)sessionDataDidRecived;
  - (void)sessionDataDidFailded;

@end

@interface JVRequestData : NSObject
<JVConnectionDelegate> {
  NSMutableDictionary *bannerData;
  NSMutableData *responseData;
  BOOL gotSessionData;
  
}

@property (nonatomic, assign) id <JVRequestDataDelegate> delegate;

@property (nonatomic, retain) NSString *appId;
@property (nonatomic, retain) NSString *signature;

@property (nonatomic, retain) NSString *sessionId;
@property (nonatomic, retain) NSString *imageServerUrl;

@property (nonatomic, retain) NSString *clientId;
@property (nonatomic, retain) NSString *appHash;


+ (JVRequestData *)manager;
- (void)startSession;


@end
