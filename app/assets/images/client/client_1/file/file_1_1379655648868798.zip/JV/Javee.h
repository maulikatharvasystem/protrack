//
//  Javee.h
//  Javee
//
//

#import <Foundation/Foundation.h>
#import "JVCommonBannerView.h"

@protocol JaveeDelegate <NSObject>
  - (void)bannerDidReceived:(JVCommonBannerView *)banner;

@end

typedef enum JVBannerType {
  JVBannerTypeGeneral = 501,       ///< Banner at bottom page
  JVBannerTypeFull = 502,          ///< Full screen banner
  JVBannerTypeCustom = 503,        ///< Custom banner type
  JVBannerTypeMoreApps = 505,      ///< More Apps banner type
  JVBannerTypePopup = 504,
  JVBannerTypeRMA = 506
} JVBannerType;


@interface Javee : NSObject {
  UIView *_banner;
}

@property (nonatomic, assign) NSString *appId;
@property (nonatomic, assign) NSString *signature;
@property (nonatomic, assign) UIViewController *rootController;
@property (nonatomic, assign) id<JaveeDelegate>delegate;
@property JVBannerType bannerType;
@property BOOL isActive;

//+ (Javee *)manager; ///< deprecated

///<- Load banners
- (void)cacheBanner;
- (void)loadBanner;
- (void)closeBanner;


@end