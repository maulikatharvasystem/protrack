//
//  JVBannerControllerDelegate.h
//  Javee
//

#import <Foundation/Foundation.h>

@protocol JVBannerControllerDelegate <NSObject>

@optional
- (void)bannerDidLoadWithView:(UIView *)bannerView;
- (void)bannerFailedLoad;
- (void)updateBanner;
- (void)hideActiveBanner;

@end
